package com.example.uni_selector

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
