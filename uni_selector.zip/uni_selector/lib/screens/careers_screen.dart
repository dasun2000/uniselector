import 'package:flutter/material.dart';

class CareersScreen extends StatelessWidget {
  const CareersScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(
        child: Text(
          'Careers Screen',
          style: TextStyle(fontSize: 24),
        ),
      ),
    );
  }
}